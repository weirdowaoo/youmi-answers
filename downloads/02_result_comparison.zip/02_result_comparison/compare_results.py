"""命令行入口：按输入顺序比较两个及以上模型版本。"""

import argparse
from decimal import Decimal, InvalidOperation
from pathlib import Path

from comparison import load_versions, write_outputs


def main() -> None:
    parser = argparse.ArgumentParser(description="对比百分制 benchmark 分数，生成 PNG 和 Markdown")
    parser.add_argument("--inputs", nargs="+", type=Path, required=True, help="版本 JSON 文件，按版本顺序传入")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent / "output")
    parser.add_argument("--threshold", default="0.5", help="持平的相对变化百分比阈值，默认 0.5")
    args = parser.parse_args()
    try:
        versions = load_versions([path.expanduser().resolve() for path in args.inputs])
        write_outputs(versions, args.output_dir.expanduser().resolve(), Decimal(args.threshold))
    except (OSError, ValueError, InvalidOperation) as error:
        parser.exit(2, f"输入或输出错误：{error}\n")
    print("已生成 comparison.png 与 report.md。")


if __name__ == "__main__":
    main()
