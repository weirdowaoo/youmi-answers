# 编程题 2：结果对比与可视化

Python 3.10+。在本目录执行：

```bash
python -m pip install -r requirements.txt
python compare_results.py --inputs examples/v1.json examples/v2.json --output-dir output
python compare_results.py --inputs examples/v1.json examples/v2.json examples/v3.json --output-dir output_multi
python -m unittest -v
```

每个输入 JSON 含 `model` 和 `results`（也支持一个文件中放版本列表）。输入顺序即版本顺序；指标为 0～100、越高越好。输出目录含 `comparison.png` 与 `report.md`。v1／v2 来自题设，v3 为演示多版本功能的构造数据，均不代表本次实测模型成绩。

- `comparison.py` 负责计算、绘图和报告，`compare_results.py` 是 CLI；两个以上版本逐相邻版本对比，并另给首尾汇总。
- Δ 为新分减旧分，单位百分点；相对变化为 Δ ÷ 旧分 × 100%。本题的“变化 <0.5% 为持平”按相对变化绝对值解释，严格小于才持平，阈值可用 `--threshold` 调整。零基线的相对变化记为不可定义，缺失指标不补零；非数字、非有限值及越界分数报错。
- 原题 C-Eval 为 −0.3 个百分点、约 −0.428%，因此归类“持平”，仍作为实际下降标红警告。报告的红色使用 HTML `span`，需支持 HTML 的 Markdown 阅读器；纯文本仍可看到 ⚠ 提示。
- 示例报告只描述分数变化，不把微小变化称为统计显著提升。图表用固定百分制纵轴；若模型名或指标名含中文，系统需有中文字体。

`output/` 保存原题双版本结果，`output_multi/` 保存三版本示例。验证结果见 [validation.txt](validation.txt)。
