from decimal import Decimal as D
import json
from pathlib import Path
import tempfile
import unittest

from comparison import Version, compare_pair, load_versions, make_report, write_outputs


def version(name, **scores):
    return Version(name, {key: D(str(value)) for key, value in scores.items()})


class ComparisonTests(unittest.TestCase):
    def test_strict_threshold_and_small_decline(self):
        changes = compare_pair(version("old", small="80", edge="80", down="80"),
                               version("new", small="80.399", edge="80.4", down="79.9"))
        self.assertEqual([c.direction for c in changes], ["持平", "上升", "持平"])
        self.assertEqual(changes[1].relative, D("0.5"))
        self.assertTrue(changes[2].declined)
        self.assertIn('color:#b42318', make_report([version("a", x=80), version("b", x="79.9")]))

    def test_zero_baseline_and_missing_values(self):
        changes = compare_pair(version("a", zero=0, equal=0, lost=5),
                               version("b", zero=1, equal=0, added=7))
        by_name = {c.benchmark: c for c in changes}
        self.assertIsNone(by_name["zero"].relative)
        self.assertEqual(by_name["zero"].direction, "上升")
        self.assertEqual(by_name["equal"].direction, "持平")
        self.assertIsNone(by_name["equal"].relative)
        self.assertEqual(by_name["lost"].direction, "缺失")
        self.assertIsNone(by_name["lost"].delta)
        self.assertEqual(by_name["added"].direction, "缺失")

    def test_original_example(self):
        directory = Path(__file__).resolve().parent / "examples"
        values = load_versions([directory / "v1.json", directory / "v2.json"])
        changes = {c.benchmark: c for c in compare_pair(*values)}
        self.assertEqual(changes["BFCL"].delta, D("6.8"))
        self.assertEqual(changes["BFCL"].direction, "上升")
        self.assertEqual(changes["C-Eval"].direction, "持平")
        report = make_report(values)
        self.assertIn("实际分数下降 1 项", report)
        self.assertIn("⚠ C-Eval", report.split("## 风险提示")[1].replace("v1 → v2：", ""))

    def test_multi_version_adjacent_and_overall(self):
        report = make_report([version("a", x=50), version("b", x=60), version("c", x=55)])
        self.assertIn("## a → b", report)
        self.assertIn("## b → c", report)
        self.assertIn("## 首尾汇总：a → c", report)
        self.assertIn("b → c：x", report)

    def test_invalid_inputs(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "versions.json"
            for invalid in [True, None, "80", -1, 101, float("nan"), float("inf")]:
                path.write_text(json.dumps([{"model": "a", "results": {"x": invalid}},
                                            {"model": "b", "results": {"x": 1}}]), encoding="utf-8")
                with self.subTest(invalid=invalid), self.assertRaises(ValueError):
                    load_versions([path])
            path.write_text('[{"model":"a","results":{"x":1}}]', encoding="utf-8")
            with self.assertRaises(ValueError):
                load_versions([path])
            for threshold in [D("-1"), D("NaN"), D("Infinity")]:
                with self.assertRaises(ValueError):
                    compare_pair(version("a", x=1), version("b", x=2), threshold)

    def test_outputs_and_png_metadata(self):
        from PIL import Image

        values = [version("a", x=50), version("b", x=49), version("c", other=60)]
        with tempfile.TemporaryDirectory() as temporary:
            destination = Path(temporary).resolve()
            write_outputs(values, destination)
            self.assertIn("缺失", (destination / "report.md").read_text(encoding="utf-8"))
            with Image.open(destination / "comparison.png") as image:
                self.assertEqual(image.format, "PNG")
                self.assertGreater(image.width, 500)
                self.assertEqual(image.info.get("Software"), "Benchmark comparison")


if __name__ == "__main__":
    unittest.main()
