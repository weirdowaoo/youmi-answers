"""百分制 benchmark 分数的计算、图表与报告。"""

from dataclasses import dataclass
from decimal import Decimal
from html import escape
import json
from pathlib import Path
from typing import Mapping, Sequence


@dataclass(frozen=True)
class Version:
    model: str
    results: Mapping[str, Decimal]


@dataclass(frozen=True)
class Change:
    benchmark: str
    before: Decimal | None
    after: Decimal | None
    delta: Decimal | None
    relative: Decimal | None
    direction: str

    @property
    def declined(self) -> bool:
        return self.delta is not None and self.delta < 0


def _reject_constant(value: str):
    raise ValueError(f"不接受非有限数字：{value}")


def _label(value: object) -> str:
    if not isinstance(value, str) or not value.strip() or any(ord(c) < 32 for c in value):
        raise ValueError("模型名和 benchmark 名须为非空、无控制字符的字符串")
    return value.strip()


def load_versions(paths: Sequence[Path]) -> list[Version]:
    """每个 JSON 可以是单个版本，也可以是版本列表；输入顺序即版本顺序。"""
    versions: list[Version] = []
    for path in paths:
        path = path.expanduser().resolve()
        data = json.loads(path.read_text(encoding="utf-8"), parse_float=Decimal,
                          parse_int=Decimal, parse_constant=_reject_constant)
        for item in data if isinstance(data, list) else [data]:
            if not isinstance(item, dict) or not isinstance(item.get("results"), dict):
                raise ValueError("每个版本须包含 model 与 results 对象")
            model = _label(item.get("model"))
            results: dict[str, Decimal] = {}
            for name, value in item["results"].items():
                benchmark = _label(name)
                if not isinstance(value, Decimal) or not value.is_finite() or not 0 <= value <= 100:
                    raise ValueError("分数须为 0～100 的有限数字；缺失指标请省略字段")
                if benchmark in results:
                    raise ValueError("benchmark 名规范化后不能重复")
                results[benchmark] = value
            if not results:
                raise ValueError("每个版本至少需要一个指标")
            versions.append(Version(model, results))
    if len(versions) < 2 or len({v.model for v in versions}) != len(versions):
        raise ValueError("至少提供两个版本，且模型名称不能重复")
    return versions


def compare_pair(old: Version, new: Version, threshold: Decimal = Decimal("0.5")) -> list[Change]:
    if not threshold.is_finite() or threshold < 0:
        raise ValueError("持平阈值须为非负有限数字")
    changes = []
    for name in dict.fromkeys([*old.results, *new.results]):
        before, after = old.results.get(name), new.results.get(name)
        if before is None or after is None:
            changes.append(Change(name, before, after, None, None, "缺失"))
            continue
        delta = after - before
        relative = delta / before * 100 if before != 0 else None
        direction = ("持平" if delta == 0 or (relative is not None and abs(relative) < threshold)
                     else "上升" if delta > 0 else "下降")
        changes.append(Change(name, before, after, delta, relative, direction))
    return changes


def _md(text: str) -> str:
    return escape(text).replace("|", "&#124;").replace("`", "&#96;")


def _number(value: Decimal | None, suffix: str = "", signed: bool = False) -> str:
    if value is None:
        return "—"
    return f"{value:+.3f}{suffix}" if signed else f"{value:.3f}{suffix}"


def make_report(versions: Sequence[Version], threshold: Decimal = Decimal("0.5")) -> str:
    """逐相邻版本比较；三个及以上版本另给首尾汇总。"""
    final = compare_pair(versions[0], versions[-1], threshold)
    counts = {kind: sum(c.direction == kind for c in final) for kind in ["上升", "下降", "持平", "缺失"]}
    declines = sum(c.declined for c in final)
    lines = ["# 评测结果对比报告", "",
             f"版本顺序：{' → '.join(_md(v.model) for v in versions)}。", "",
             f"口径：分数为 0～100，均为越高越好；Δ 是新分减旧分（百分点）；相对变化 = Δ ÷ 旧分 × 100%。"
             f"相对变化的绝对值严格小于 {threshold}% 记为持平，等于阈值不记持平；分数完全相同也记持平。"
             "旧分为零时相对变化不可定义，按实际增减标方向；缺失指标不补零。", "",
             "## 总体结论", "",
             f"首尾版本对比：上升 {counts['上升']} 项、下降 {counts['下降']} 项、持平 {counts['持平']} 项，"
             f"另有 {counts['缺失']} 项因缺失不能比较。实际分数下降 {declines} 项（含归类为持平的下降）。"
             "这些是观测分数变化，不能据此直接判断统计显著性。", "",
             "## 风险提示", ""]
    risks = []
    for old, new in zip(versions, versions[1:]):
        for c in compare_pair(old, new, threshold):
            if c.declined:
                risks.append(f"- <span style=\"color:#b42318\">⚠ {_md(old.model)} → {_md(new.model)}："
                             f"{_md(c.benchmark)} {_number(c.delta, ' 个百分点', True)}"
                             f"（{_number(c.relative, '%', True)}，方向归类：{c.direction}）。</span>")
            elif c.direction == "缺失":
                risks.append(f"- {_md(old.model)} → {_md(new.model)}：{_md(c.benchmark)} 缺失，不能判断变化。")
    lines += risks or ["- 无实际下降或缺失项。"]
    pairs = [(f"{old.model} → {new.model}", old, new) for old, new in zip(versions, versions[1:])]
    if len(versions) > 2:
        pairs.append((f"首尾汇总：{versions[0].model} → {versions[-1].model}", versions[0], versions[-1]))
    for title, old, new in pairs:
        lines += ["", f"## {_md(title)}", "",
                  f"| Benchmark | {_md(old.model)} | {_md(new.model)} | Δ（百分点） | 相对变化 | 方向 |",
                  "|---|---:|---:|---:|---:|---|"]
        for c in compare_pair(old, new, threshold):
            delta = _number(c.delta, signed=True)
            if c.declined:
                delta = f'<span style="color:#b42318">⚠ {delta}</span>'
            relative = "不可定义（零基线）" if c.before == 0 and c.after is not None else _number(c.relative, "%", True)
            lines.append(f"| {_md(c.benchmark)} | {_number(c.before)} | {_number(c.after)} | "
                         f"{delta} | {relative} | {c.direction} |")
    return "\n".join(lines) + "\n"


def plot_versions(versions: Sequence[Version], destination: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib import font_manager

    fonts = {font.name for font in font_manager.fontManager.ttflist}
    for font in ("Noto Sans CJK SC", "WenQuanYi Zen Hei", "Microsoft YaHei", "SimHei"):
        if font in fonts:
            plt.rcParams["font.sans-serif"] = [font, "DejaVu Sans"]
            break
    plt.rcParams["axes.unicode_minus"] = False
    benchmarks = list(dict.fromkeys(name for version in versions for name in version.results))
    width = 0.8 / len(versions)
    fig, ax = plt.subplots(figsize=(max(8, len(benchmarks) * 1.3), 5), layout="constrained")
    for index, version in enumerate(versions):
        positions = [i - 0.4 + width / 2 + index * width for i in range(len(benchmarks))]
        scores = [float(version.results[name]) if name in version.results else float("nan") for name in benchmarks]
        ax.bar(positions, scores, width=width, label=version.model)
        for x, name in zip(positions, benchmarks):
            if name not in version.results:
                ax.text(x, 1, "N/A", rotation=90, ha="center", fontsize=8)
    ax.set_xticks(range(len(benchmarks)), benchmarks)
    ax.set_ylim(0, 105)
    ax.set_ylabel("分数（0～100，越高越好）")
    ax.set_title("各模型版本评测分数对比")
    ax.grid(axis="y", alpha=0.2)
    ax.set_axisbelow(True)
    ax.legend(ncols=min(len(versions), 4))
    destination = destination.expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(destination, dpi=150, metadata={"Software": "Benchmark comparison"})
    plt.close(fig)


def write_outputs(versions: Sequence[Version], directory: Path, threshold: Decimal = Decimal("0.5")) -> None:
    report = make_report(versions, threshold)
    directory = directory.expanduser().resolve()
    directory.mkdir(parents=True, exist_ok=True)
    plot_versions(versions, directory / "comparison.png")
    (directory / "report.md").write_text(report, encoding="utf-8")
