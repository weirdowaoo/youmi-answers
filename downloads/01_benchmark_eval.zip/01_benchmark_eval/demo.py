"""本地模拟接口演示，不访问外部模型，也不需要真实密钥。"""

from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import subprocess
import sys
from threading import Thread
from urllib.parse import urlunsplit


@contextmanager
def mock_api(responses):
    requests = []
    iterator = iter(responses)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_POST(self):
            requests.append({
                "path": self.path,
                "body": json.loads(self.rfile.read(int(self.headers["Content-Length"]))),
            })
            result = next(iterator)
            if isinstance(result, bytes):
                self.send_response(200)
                self.send_header("Content-Length", str(len(result) + 10))
                self.end_headers()
                self.wfile.write(result)
                self.close_connection = True
                return
            if isinstance(result, int):
                self.send_response(result)
                self.end_headers()
                self.wfile.write(b"private error body must not be logged")
                return
            body = json.dumps({
                "choices": [{"message": {"content": result}, "finish_reason": "stop"}]
            }).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield urlunsplit(("http", f"127.0.0.1:{server.server_port}", "/v1", "", "")), requests
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def main():
    directory = Path(__file__).resolve().parent
    responses = ["答案是B", "C", "C. 错误选项", "A 或 B"]
    with mock_api(responses) as (base_url, _):
        command = [
            sys.executable, str(directory / "benchmark_eval.py"),
            "--train", str(directory / "examples" / "train.jsonl"),
            "--eval", str(directory / "examples" / "eval.jsonl"),
            "--base-url", base_url, "--model", "demo-model",
            "--output", str(directory / "sample_result.json"),
        ]
        subprocess.run(command, check=True)


if __name__ == "__main__":
    main()
