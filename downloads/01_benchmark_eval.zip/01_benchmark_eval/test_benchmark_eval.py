import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from benchmark_eval import ChatClient, build_messages, evaluate, load_jsonl, parse_answer, sample_fewshot
from demo import mock_api


DIRECTORY = Path(__file__).resolve().parent


class EvaluationTests(unittest.TestCase):
    def setUp(self):
        self.train = load_jsonl(DIRECTORY / "examples" / "train.jsonl")
        self.rows = load_jsonl(DIRECTORY / "examples" / "eval.jsonl")

    def test_answer_formats_and_ambiguity(self):
        for value in ("B", "答案是B", "B. xxx", "Answer: (b)", "Ｂ", "选项B"):
            with self.subTest(value=value):
                self.assertEqual(parse_answer(value), "B")
        for value in ("A 或 B", "A 或 b", "答案是b或c", "b or c", "答案是B，也可能是C",
                      "不选B", "B. not sure", "AB", "无法判断", "E", "", None):
            with self.subTest(value=value):
                self.assertIsNone(parse_answer(value))

    def test_fewshot_seed_dedup_and_no_eval_leak(self):
        contaminated = self.train + self.train + [self.rows[0]]
        first = sample_fewshot(contaminated, self.rows, 42)
        self.assertEqual(first, sample_fewshot(contaminated, self.rows, 42))
        self.assertEqual(len({row["question"] for row in first}), 3)
        self.assertTrue({row["question"] for row in first}.isdisjoint(
            row["question"] for row in self.rows))
        with self.assertRaises(ValueError):
            sample_fewshot([self.rows[0]], self.rows)
        messages = build_messages(first, self.rows[0])
        self.assertEqual([message["role"] for message in messages],
                         ["system", "user", "assistant", "user", "assistant", "user", "assistant", "user"])
        self.assertNotIn("answer", messages[-1])

    def test_invalid_input_fails_before_scoring(self):
        with tempfile.TemporaryDirectory() as temporary:
            invalid = Path(temporary).resolve() / "bad.jsonl"
            invalid.write_text(json.dumps({"question": "bad", "choices": ["a"], "answer": "AB"}), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "第 1 行"):
                load_jsonl(invalid)

    def test_cli_calls_http_and_reports_real_denominators(self):
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary).resolve() / "report.json"
            with mock_api(["答案是B", "C", "C. 错误选项", "A 或 B"]) as (base_url, requests):
                result = subprocess.run([
                    sys.executable, str(DIRECTORY / "benchmark_eval.py"),
                    "--train", str(DIRECTORY / "examples" / "train.jsonl"),
                    "--eval", str(DIRECTORY / "examples" / "eval.jsonl"),
                    "--base-url", base_url, "--model", "demo-model", "--output", str(output),
                ], capture_output=True, text=True, check=True)
            report = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual(report, json.loads(result.stdout))
            self.assertEqual((report["total"], report["correct"], report["accuracy"]), (4, 2, 0.5))
            self.assertEqual((report["api_errors"], report["unparsed"]), (0, 1))
            self.assertEqual(report["categories"]["math"]["accuracy"], 0.5)
            self.assertEqual(report["categories"]["science"]["accuracy"], 0.5)
            self.assertEqual(len(requests), 4)
            for request in requests:
                self.assertEqual(request["path"], "/v1/chat/completions")
                self.assertEqual(request["body"]["model"], "demo-model")
                self.assertEqual(request["body"]["temperature"], 0)
                self.assertFalse(request["body"]["stream"])
                self.assertEqual(len(request["body"]["messages"]), 8)
            shots = requests[0]["body"]["messages"][1:7]
            self.assertTrue(all(request["body"]["messages"][1:7] == shots for request in requests))

    def test_http_failure_is_counted_and_body_is_not_exposed(self):
        shots = sample_fewshot(self.train, self.rows)
        with mock_api([401, "C"]) as (base_url, _):
            report = evaluate(self.rows[:2], shots, ChatClient(base_url, "demo-model"))
        self.assertEqual((report["total"], report["correct"], report["api_errors"]), (2, 1, 1))
        self.assertEqual(report["accuracy"], 0.5)
        self.assertEqual(report["details"][0]["error"], "HTTP 401")
        self.assertNotIn("private error body", json.dumps(report))

    def test_missing_category_and_malformed_response(self):
        row = {key: value for key, value in self.rows[0].items() if key != "category"}
        shots = sample_fewshot(self.train, self.rows)
        with mock_api([None]) as (base_url, _):
            report = evaluate([row], shots, ChatClient(base_url, "demo-model"))
        self.assertEqual(report["api_errors"], 1)
        self.assertEqual(report["categories"]["未分类"]["total"], 1)

    def test_interrupted_response_keeps_denominator_and_continues(self):
        shots = sample_fewshot(self.train, self.rows)
        with mock_api([b"{}", "C"]) as (base_url, _):
            report = evaluate(self.rows[:2], shots, ChatClient(base_url, "demo-model"))
        self.assertEqual((report["total"], report["correct"], report["api_errors"]), (2, 1, 1))
        self.assertEqual(report["accuracy"], 0.5)
        self.assertEqual(report["details"][0]["error"], "网络请求失败或超时")


if __name__ == "__main__":
    unittest.main()
