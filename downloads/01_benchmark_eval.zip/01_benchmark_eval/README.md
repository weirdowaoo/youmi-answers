# 编程题 1：Benchmark 评测脚本

我按题目给出的单字母 `answer` 字段实现四选一评测，使用训练集中的 3 条样例构造 few-shot 提示词，再解析模型输出并计算总体和分类准确率。

Python 3.10+，仅用标准库，无需安装第三方依赖。`benchmark_eval.py` 包含数据校验、抽样、提示词、API 调用、答案解析和统计等可复用函数。

在本目录执行：

```bash
python demo.py
python -m unittest -v
```

`demo.py` 启动本地模拟接口并实际调用命令行脚本，生成 `sample_result.json`。预期总题数 4、正确数 2、准确率 0.5；math、science 均为 0.5；另有 1 条答案无法唯一解析。该演示不调用真实模型。

接真实接口时，先在环境变量中配置自己的 `OPENAI_BASE_URL`、`OPENAI_MODEL`，需要认证时再设置 `OPENAI_API_KEY`：

```bash
python benchmark_eval.py --train examples/train.jsonl --eval examples/eval.jsonl --output result.json
```

也可使用 `--base-url`、`--model` 覆盖地址和模型；地址应为含服务所需版本前缀的 API 根地址，不包含末尾的 `/chat/completions`。支持非流式文本 Chat Completions，默认 `temperature=0`；不同模型的参数兼容性需以服务实际支持为准。

- 每行包含非空 `question`、4 个 `choices`、单字母 `answer`；`category` 可选。准确率取值为 0～1。
- 从去重、排除评测重叠题后的训练集中，用固定种子随机抽取 3 题，整轮复用；不会把评测题答案放进提示词。文本去重不能识别所有近义改写，正式数据仍需独立划分。
- 支持 `答案是B`、`B`、`B. xxx` 等格式。出现多个候选、无法解析、API 失败或非正常结束时计错，并单独记录，仍保留在分母中；不将原始错误响应写入结果。
- 输出包括总体、分类统计及逐题预测；无分类的样本归入“未分类”。输入数据格式错误会在发送请求前停止。
- 固定种子与温度不能保证硬件、服务版本变化时逐字一致。该脚本不做生产级并发、重试或断点续跑。

验证记录：已在 Python 3.11 下通过 7 项离线测试，覆盖请求体与 3-shot、答案解析、抽样去重、防评测重叠、总体／分类计分、异常分母、响应中途断开和错误正文隔离；已实际生成示例 JSON。真实模型 API 联调尚未验证。
