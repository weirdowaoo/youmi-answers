"""四选一评测：独立训练集 3-shot、Chat Completions、总体与分类准确率。"""

import argparse
from collections import defaultdict
from http.client import HTTPException
import json
import math
import os
from pathlib import Path
import random
import re
import unicodedata
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from urllib.request import Request, urlopen


LETTERS = "ABCD"


def load_jsonl(path):
    """输入错误在请求模型前报错，避免悄悄跳过坏数据。"""
    rows = []
    with Path(path).resolve().open(encoding="utf-8") as source:
        for line_number, line in enumerate(source, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
                valid = (
                    isinstance(row, dict)
                    and isinstance(row.get("question"), str)
                    and bool(row["question"].strip())
                    and isinstance(row.get("choices"), list)
                    and len(row["choices"]) == 4
                    and all(isinstance(x, str) and x.strip() for x in row["choices"])
                    and isinstance(row.get("answer"), str)
                    and row["answer"] in LETTERS
                    and len(row["answer"]) == 1
                    and ("category" not in row or isinstance(row["category"], str))
                )
                if not valid:
                    raise ValueError
            except (ValueError, TypeError):
                raise ValueError(f"JSONL 第 {line_number} 行不符合题目数据格式") from None
            rows.append(row)
    if not rows:
        raise ValueError("JSONL 至少需要一条有效样本")
    return rows


def sample_fewshot(train_rows, eval_rows, seed=42):
    """整轮固定 3 个示例；去重并排除与评测题干相同的训练题。"""
    def question_key(row):
        text = unicodedata.normalize("NFKC", row["question"])
        return " ".join(text.split()).casefold()

    excluded = {question_key(row) for row in eval_rows}
    unique = {}
    for row in train_rows:
        key = question_key(row)
        if key not in excluded:
            unique.setdefault(key, row)
    if len(unique) < 3:
        raise ValueError("排除评测重叠题并去重后，训练集至少需要 3 道题")
    return random.Random(seed).sample(list(unique.values()), 3)


def format_question(row):
    options = "\n".join(f"{letter}. {text}" for letter, text in zip(LETTERS, row["choices"]))
    return f"{row['question']}\n{options}\n请只回答一个选项字母（A/B/C/D）。"


def build_messages(fewshot, row):
    messages = [{"role": "system", "content": "完成四选一选择题，只输出一个选项字母。"}]
    for example in fewshot:
        messages.extend([
            {"role": "user", "content": format_question(example)},
            {"role": "assistant", "content": example["answer"]},
        ])
    messages.append({"role": "user", "content": format_question(row)})
    return messages


def parse_answer(text):
    """接受纯字母、开头标签或明确答案标记；出现多个候选时拒绝猜测。"""
    if not isinstance(text, str):
        return None
    text = unicodedata.normalize("NFKC", text).strip()
    if re.search(r"不选|不能选|不是|不确定|无法确定|不能确定|not\s+sure|uncertain", text, re.IGNORECASE):
        return None
    direct = re.fullmatch(r"[\[(]?([A-Da-d])[\])]?\.?", text)
    if direct:
        return direct.group(1).upper()
    marked = re.findall(
        r"(?:答案\s*(?:是|为|[:：])?|(?:我)?选(?:择)?|选项|answer\s*(?:is|:))"
        r"\s*[\[(]?([A-D])(?=$|[^a-zA-Z0-9_])", text, re.IGNORECASE,
    )
    leading = re.match(r"^[\[(]?([A-Da-d])[\])]?(?=[.、:：\s])", text)
    candidates = set(re.findall(r"(?<![a-zA-Z0-9_])([A-D])(?![a-zA-Z0-9_])", text))
    alternatives = re.findall(
        r"(?<![a-zA-Z0-9_])([A-D])\s*(?:或(?:者)?|和|及|and|or|[/、,，])"
        r"\s*([A-D])(?![a-zA-Z0-9_])", text, re.IGNORECASE,
    )
    candidates.update(letter.upper() for pair in alternatives for letter in pair)
    candidates.update(answer.upper() for answer in marked)
    if leading:
        candidates.add(leading.group(1).upper())
    return candidates.pop() if len(candidates) == 1 and (marked or leading) else None


class APIError(Exception):
    """只包含可公开的错误类型，不携带响应正文、请求头或端点。"""


class ChatClient:
    def __init__(self, base_url, model, timeout=30):
        parsed = urlsplit(base_url)
        if (parsed.scheme not in {"http", "https"} or not parsed.hostname
                or parsed.username or parsed.password or parsed.query or parsed.fragment):
            raise ValueError("base_url 必须是无凭据、查询参数和片段的 HTTP(S) API 根地址")
        if not model.strip() or not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("model 不得为空，timeout 必须为正有限数")
        self.endpoint = base_url.rstrip("/") + "/chat/completions"
        self.model = model
        self.timeout = timeout

    def complete(self, messages):
        headers = {"Content-Type": "application/json"}
        key = os.environ.get("OPENAI_API_KEY")
        if key:
            headers["Authorization"] = f"Bearer {key}"
        body = json.dumps({
            "model": self.model, "messages": messages, "temperature": 0, "stream": False,
        }).encode("utf-8")
        request = Request(self.endpoint, data=body, headers=headers, method="POST")
        try:
            with urlopen(request, timeout=self.timeout) as response:
                data = json.loads(response.read())
            choice = data["choices"][0]
            content = choice["message"]["content"]
            if choice.get("finish_reason") != "stop" or not isinstance(content, str):
                raise APIError("响应未正常结束或正文不是文本")
            return content
        except HTTPError as error:
            raise APIError(f"HTTP {error.code}") from None
        except (URLError, TimeoutError, OSError, HTTPException):
            raise APIError("网络请求失败或超时") from None
        except (ValueError, KeyError, IndexError, TypeError):
            raise APIError("响应不符合 Chat Completions 格式") from None


def evaluate(rows, fewshot, client):
    counts = defaultdict(lambda: {"total": 0, "correct": 0})
    details = []
    errors = unparsed = 0
    for index, row in enumerate(rows, 1):
        category = row.get("category") or "未分类"
        error = None
        prediction = None
        try:
            prediction = parse_answer(client.complete(build_messages(fewshot, row)))
            if prediction is None:
                unparsed += 1
                error = "答案无法唯一解析"
        except APIError as exception:
            errors += 1
            error = str(exception)
        correct = prediction == row["answer"]
        counts[category]["total"] += 1
        counts[category]["correct"] += int(correct)
        details.append({
            "index": index, "category": category, "answer": row["answer"],
            "prediction": prediction, "correct": correct, "error": error,
        })
    total = len(rows)
    correct = sum(row["correct"] for row in details)
    return {
        "total": total, "correct": correct, "accuracy": correct / total if total else 0.0,
        "api_errors": errors, "unparsed": unparsed,
        "categories": {
            key: {**value, "accuracy": value["correct"] / value["total"]}
            for key, value in sorted(counts.items())
        },
        "details": details,
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--train", type=Path, required=True)
    parser.add_argument("--eval", type=Path, required=True, dest="eval_file")
    parser.add_argument("--base-url", default=os.environ.get("OPENAI_BASE_URL"))
    parser.add_argument("--model", default=os.environ.get("OPENAI_MODEL"))
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--timeout", type=float, default=30)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args(argv)
    if not args.base_url or not args.model:
        parser.error("需要 --base-url/--model，或 OPENAI_BASE_URL/OPENAI_MODEL 环境变量")
    try:
        if args.train.resolve() == args.eval_file.resolve():
            raise ValueError("训练集和评测集必须是不同文件")
        train_rows = load_jsonl(args.train)
        rows = load_jsonl(args.eval_file)
        fewshot = sample_fewshot(train_rows, rows, args.seed)
        report = evaluate(rows, fewshot, ChatClient(args.base_url, args.model, args.timeout))
        report["settings"] = {"model": args.model, "seed": args.seed, "fewshot": 3, "temperature": 0}
        serialized = json.dumps(report, ensure_ascii=False, indent=2)
        if args.output:
            output = args.output.resolve()
            output.parent.mkdir(parents=True, exist_ok=True)
            output.write_text(serialized + "\n", encoding="utf-8")
        print(serialized)
    except ValueError as error:
        parser.error(str(error))
    except OSError:
        parser.error("输入文件无法读取或输出文件无法写入")


if __name__ == "__main__":
    main()
